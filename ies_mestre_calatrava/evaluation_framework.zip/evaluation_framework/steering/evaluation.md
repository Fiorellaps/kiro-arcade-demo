---
inclusion: auto
---

# Sistema de Evaluación del Workshop Kiro Arcade

## Objetivo
Este steering guía la evaluación del progreso y calidad del trabajo de los alumnos durante el workshop. Kiro debe registrar y facilitar la evaluación de las interacciones.

## Criterios de Evaluación

### 1. Uso de Prompts (0-25 puntos)
- **Claridad** (0-10): Los prompts son claros, específicos y bien estructurados
- **Iteración** (0-10): El alumno itera y refina sus prompts basándose en resultados
- **Autonomía** (0-5): Capacidad de formular prompts sin ayuda externa

### 2. Comprensión del Código (0-25 puntos)
- **Lectura** (0-10): Demuestra entender el código generado/modificado
- **Modificación** (0-10): Realiza cambios coherentes sobre el código existente
- **Debugging** (0-5): Identifica y resuelve errores con ayuda de Kiro

### 3. Uso de Features de Kiro (0-25 puntos)
- **Specs** (0-10): Usa el flujo de specs (requirements → design → tasks)
- **Steering** (0-5): Configura steering files para guiar al agente
- **Hooks** (0-5): Crea o modifica hooks para automatizar flujos
- **Vibe mode** (0-5): Usa el modo conversacional de forma efectiva

### 4. Resultado Final (0-25 puntos)
- **Funcionalidad** (0-10): El juego/feature funciona correctamente
- **Calidad** (0-10): Código limpio, sin errores en consola, buena UX
- **Creatividad** (0-5): Aporta ideas propias más allá del enunciado

## Niveles de Desempeño
- **Sobresaliente** (90-100): Dominio completo de Kiro, resultado excelente
- **Notable** (70-89): Buen uso de Kiro, resultado sólido
- **Aprobado** (50-69): Uso básico de Kiro, resultado funcional
- **Insuficiente** (<50): No completa los objetivos mínimos

## Instrucciones para el Registro
- Cada interacción relevante debe quedar registrada en el log de evaluación
- Los hooks capturan automáticamente: prompts enviados, archivos editados, archivos creados
- Al finalizar la sesión, generar el fichero de entrega con el resumen
