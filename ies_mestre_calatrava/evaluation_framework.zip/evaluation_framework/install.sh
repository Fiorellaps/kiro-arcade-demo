#!/bin/bash
# ============================================================
# Kiro Evaluation Framework — Installer
# ============================================================
# Este script instala el sistema de evaluación en cualquier
# proyecto Kiro. Ejecutar desde la raíz del proyecto.
# ============================================================

set -e

echo "🎯 Instalando Kiro Evaluation Framework..."
echo ""

# Verificar que estamos en la raíz de un proyecto
if [ ! -d ".kiro" ]; then
    echo "⚠️  No se encontró carpeta .kiro — creándola..."
    mkdir -p .kiro
fi

# Obtener el directorio donde está este script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Crear estructura de carpetas
echo "📁 Creando estructura de carpetas..."
mkdir -p .kiro/hooks
mkdir -p .kiro/steering
mkdir -p .kiro/evaluation

# Copiar hooks
echo "🪝 Instalando hooks..."
cp "$SCRIPT_DIR/hooks/"*.kiro.hook .kiro/hooks/
echo "   ✓ log-student-prompts.kiro.hook"
echo "   ✓ log-file-edits.kiro.hook"
echo "   ✓ log-file-creates.kiro.hook"
echo "   ✓ session-summary.kiro.hook"
echo "   ✓ protect-evaluation.kiro.hook"

# Copiar steerings
echo "📐 Instalando steering files..."
cp "$SCRIPT_DIR/steering/"*.md .kiro/steering/
echo "   ✓ evaluation.md"
echo "   ✓ protected-files.md"

# Copiar templates de evaluación
echo "📝 Instalando templates de evaluación..."
cp "$SCRIPT_DIR/templates/rubrica.md" .kiro/evaluation/
cp "$SCRIPT_DIR/templates/entregable-alumno.md" .kiro/evaluation/
cp "$SCRIPT_DIR/templates/session-summary.md" .kiro/evaluation/

# Crear logs vacíos
touch .kiro/evaluation/activity.log
touch .kiro/evaluation/chat-history.log

# Proteger ficheros de evaluación (read-only)
echo "🔒 Protegiendo ficheros de evaluación..."
chmod 444 .kiro/evaluation/rubrica.md
chmod 444 .kiro/evaluation/entregable-alumno.md
# Los logs necesitan ser escribibles por los hooks
chmod 666 .kiro/evaluation/activity.log
chmod 666 .kiro/evaluation/chat-history.log
chmod 666 .kiro/evaluation/session-summary.md

echo ""
echo "✅ Framework de evaluación instalado correctamente!"
echo ""
echo "Estructura creada:"
echo "  .kiro/"
echo "  ├── hooks/"
echo "  │   ├── log-student-prompts.kiro.hook"
echo "  │   ├── log-file-edits.kiro.hook"
echo "  │   ├── log-file-creates.kiro.hook"
echo "  │   ├── session-summary.kiro.hook"
echo "  │   └── protect-evaluation.kiro.hook"
echo "  ├── steering/"
echo "  │   ├── evaluation.md"
echo "  │   └── protected-files.md"
echo "  └── evaluation/"
echo "      ├── rubrica.md (read-only)"
echo "      ├── entregable-alumno.md (read-only)"
echo "      ├── session-summary.md"
echo "      ├── activity.log"
echo "      └── chat-history.log"
echo ""
echo "💡 Abre el proyecto en Kiro y los hooks se activarán automáticamente."
