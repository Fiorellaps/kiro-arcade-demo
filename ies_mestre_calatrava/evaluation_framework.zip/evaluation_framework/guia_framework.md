# Guía del Framework de Evaluación para Kiro Workshops

## ¿Qué es esto?

Un sistema listo para instalar que permite a instructores **evaluar automáticamente** el trabajo de alumnos en workshops de Kiro. Incluye:

- **Hooks** que registran actividad del alumno (prompts, ediciones, creaciones)
- **Steerings** que configuran criterios de evaluación y protegen ficheros
- **Templates** de rúbrica, entregable y resumen de sesión

---

## Estructura del Framework

```
evaluation_framework/
├── guia_framework.md          ← Esta guía
├── install.sh                 ← Script de instalación automática
├── hooks/
│   ├── log-student-prompts.kiro.hook   — Registra cada prompt enviado
│   ├── log-file-edits.kiro.hook        — Registra ediciones a código
│   ├── log-file-creates.kiro.hook      — Registra ficheros nuevos creados
│   ├── session-summary.kiro.hook       — Genera resumen al terminar sesión
│   └── protect-evaluation.kiro.hook    — Bloquea escritura a evaluation/
├── steering/
│   ├── evaluation.md                   — Criterios y rúbrica para el agente
│   └── protected-files.md             — Regla de protección de ficheros
└── templates/
    ├── rubrica.md                      — Rúbrica de calificación (0-100)
    ├── entregable-alumno.md            — Template que llena el alumno
    └── session-summary.md              — Log de sesiones (auto-llenado)
```

---

## Instalación Rápida

### Opción 1: Script automático (recomendado)

Desde la **raíz del proyecto** del alumno:

```bash
chmod +x evaluation_framework/install.sh
./evaluation_framework/install.sh
```

### Opción 2: Instalación manual

1. **Copiar hooks** a `.kiro/hooks/`:
```bash
mkdir -p .kiro/hooks
cp evaluation_framework/hooks/*.kiro.hook .kiro/hooks/
```

2. **Copiar steerings** a `.kiro/steering/`:
```bash
mkdir -p .kiro/steering
cp evaluation_framework/steering/*.md .kiro/steering/
```

3. **Copiar templates** a `.kiro/evaluation/`:
```bash
mkdir -p .kiro/evaluation
cp evaluation_framework/templates/*.md .kiro/evaluation/
touch .kiro/evaluation/activity.log
touch .kiro/evaluation/chat-history.log
```

4. **Proteger ficheros** (opcional pero recomendado):
```bash
chmod 444 .kiro/evaluation/rubrica.md
chmod 444 .kiro/evaluation/entregable-alumno.md
```

### Opción 3: Pedírselo a Kiro

Abre Kiro en el proyecto del alumno y escríbele:

> "Instala el framework de evaluación. Copia los hooks de `evaluation_framework/hooks/` a `.kiro/hooks/`, los steerings de `evaluation_framework/steering/` a `.kiro/steering/`, y los templates de `evaluation_framework/templates/` a `.kiro/evaluation/`. También crea los ficheros vacíos `activity.log` y `chat-history.log` en `.kiro/evaluation/`."

---

## Cómo funciona

### Captura automática de actividad

| Hook | Evento | Qué registra |
|------|--------|--------------|
| `log-student-prompts` | Cada prompt enviado | Timestamp en `chat-history.log` |
| `log-file-edits` | Edición de código | Timestamp en `activity.log` |
| `log-file-creates` | Creación de fichero | Timestamp en `activity.log` |
| `session-summary` | Fin de sesión del agente | Resumen completo en `session-summary.md` |

### Protección de ficheros

| Mecanismo | Qué protege |
|-----------|-------------|
| Hook `protect-evaluation` | Bloquea escrituras del agente a `.kiro/evaluation/` |
| Steering `protected-files.md` | Instrucción directa al agente de no modificar evaluation |
| `chmod 444` (filesystem) | Impide edición manual directa |

### Criterios de evaluación (steering)

El steering `evaluation.md` le dice al agente los criterios de calificación:
- Uso de Prompts (25 pts)
- Comprensión del Código (25 pts)
- Uso de Features de Kiro (25 pts)
- Resultado Final (25 pts)

---

## Para el Instructor

### Antes del workshop
1. Instalar el framework en el repo base
2. Hacer commit y push
3. Los alumnos clonan y abren en Kiro → todo se activa automáticamente

### Durante el workshop
- Los hooks registran actividad en segundo plano
- El alumno no puede modificar la rúbrica ni los criterios
- `session-summary.md` se va llenando con cada interacción

### Después del workshop
1. Pedir al alumno que haga commit de su carpeta `.kiro/evaluation/`
2. Revisar `session-summary.md` para ver el historial de interacciones
3. Revisar `activity.log` y `chat-history.log` para métricas cuantitativas
4. Usar `rubrica.md` como guía para calificar

### Recolección de datos
```bash
# Recoger evaluaciones de todos los alumnos
for student_dir in students/*/; do
    cp -r "$student_dir/.kiro/evaluation/" "evaluaciones/$(basename $student_dir)/"
done
```

---

## Personalización

### Cambiar qué archivos se monitorean

Edita los `patterns` en los hooks de `log-file-edits` y `log-file-creates`:

```json
"patterns": ["src/*.html", "*.py", "*.js", "*.css", "index.html"]
```

### Cambiar criterios de evaluación

Edita `steering/evaluation.md` para ajustar puntos, categorías o niveles.

### Añadir más hooks

Crea un nuevo `.kiro.hook` en la carpeta `hooks/` siguiendo el formato JSON estándar de Kiro.

---

## Limitaciones conocidas

- **No es 100% anti-tampering**: Un alumno técnico podría editar los `.kiro.hook` directamente o revertir con git. El `chmod 444` y el steering son disuasorios, no barreras absolutas.
- **Los hooks `runCommand`** requieren que Kiro esté en modo **Autopilot** para ejecutarse sin confirmación.
- **`session-summary`** intenta escribir en `.kiro/evaluation/session-summary.md` pero el steering `protected-files.md` puede bloquearlo. Si quieres que el hook de resumen funcione, el steering de protección debería permitir escrituras internas del hook o desactivarse para el instructor.

---

## Troubleshooting

| Problema | Solución |
|----------|----------|
| Los hooks piden confirmación cada vez | Cambiar Kiro a modo Autopilot (barra de estado) |
| `session-summary` no se actualiza | Conflicto con steering de protección — ajustar reglas |
| El alumno editó la rúbrica manualmente | Verificar con `git diff .kiro/evaluation/rubrica.md` |
| Los logs están vacíos | Verificar que hooks están en `.kiro/hooks/` y Kiro los cargó |
| Hook no se dispara | Verificar que el campo `"enabled": true` está presente |
