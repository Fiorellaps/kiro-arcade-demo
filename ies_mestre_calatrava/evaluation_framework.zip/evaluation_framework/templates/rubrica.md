# Rúbrica de Evaluación — Kiro Arcade Workshop

## Datos del Alumno
- **Nombre:** _________________
- **Fecha:** _________________
- **Juego/Feature asignado:** _________________

---

## 1. Uso de Prompts (0-25 pts)

| Criterio | Descripción | Puntos |
|----------|-------------|--------|
| Claridad (0-10) | Los prompts son específicos, bien escritos y con contexto suficiente | /10 |
| Iteración (0-10) | Refina prompts basándose en resultados, no repite el mismo error | /10 |
| Autonomía (0-5) | Formula prompts sin copiar ejemplos literalmente, adapta al contexto | /5 |

**Subtotal:** ___/25

---

## 2. Comprensión del Código (0-25 pts)

| Criterio | Descripción | Puntos |
|----------|-------------|--------|
| Lectura (0-10) | Entiende el código generado, puede explicar qué hace | /10 |
| Modificación (0-10) | Realiza cambios coherentes que no rompen funcionalidad existente | /10 |
| Debugging (0-5) | Identifica errores y los comunica bien a Kiro para resolverlos | /5 |

**Subtotal:** ___/25

---

## 3. Uso de Features de Kiro (0-25 pts)

| Criterio | Descripción | Puntos |
|----------|-------------|--------|
| Specs (0-10) | Creó/usó specs para planificar antes de implementar | /10 |
| Steering (0-5) | Configuró reglas de steering para guiar al agente | /5 |
| Hooks (0-5) | Creó al menos un hook funcional | /5 |
| Vibe mode (0-5) | Usó chat conversacional para explorar soluciones | /5 |

**Subtotal:** ___/25

---

## 4. Resultado Final (0-25 pts)

| Criterio | Descripción | Puntos |
|----------|-------------|--------|
| Funcionalidad (0-10) | El juego/feature funciona sin errores críticos | /10 |
| Calidad (0-10) | Código limpio, sin errores en consola, UI coherente con el tema | /10 |
| Creatividad (0-5) | Ideas propias, mejoras no solicitadas, toque personal | /5 |

**Subtotal:** ___/25

---

## Resumen

| Sección | Puntos |
|---------|--------|
| 1. Uso de Prompts | /25 |
| 2. Comprensión del Código | /25 |
| 3. Uso de Features de Kiro | /25 |
| 4. Resultado Final | /25 |
| **TOTAL** | **/100** |

### Nivel de Desempeño
- [ ] Sobresaliente (90-100)
- [ ] Notable (70-89)
- [ ] Aprobado (50-69)
- [ ] Insuficiente (<50)

### Observaciones del Evaluador
```
_____________________________________________________________
```
