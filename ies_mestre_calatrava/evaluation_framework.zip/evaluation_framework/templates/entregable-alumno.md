# Entregable de Evaluación — Kiro Arcade Workshop

## Datos del Alumno
- **Nombre:** _________________
- **Email:** _________________
- **Fecha del Workshop:** _________________
- **Juego/Feature desarrollado:** _________________

---

## 1. Descripción del Proyecto
<!-- Describe brevemente qué construiste durante el workshop -->

```
_____________________________________________________________
```

---

## 2. Features de Kiro Utilizadas

Marca con [x] las que usaste:

- [ ] **Vibe Mode** — Chat conversacional libre para generar código
- [ ] **Spec Mode** — Flujo estructurado (Requirements → Design → Tasks)
- [ ] **Steering Files** — Reglas personalizadas para guiar al agente
- [ ] **Agent Hooks** — Automatizaciones (lint on save, tests, etc.)
- [ ] **MCP Tools** — Herramientas externas conectadas
- [ ] **Context references** — Uso de #File, #Folder, #Problems, etc.

---

## 3. Prompts Destacados

### Mejor prompt que escribiste:
```
_____________________________________________________________
```

### ¿Por qué fue efectivo?
```
_____________________________________________________________
```

### Prompt que requirió más iteración:
```
_____________________________________________________________
```

### ¿Qué aprendiste de la iteración?
```
_____________________________________________________________
```

---

## 4. Reflexión sobre el Proceso

### ¿Qué fue lo más fácil de usar en Kiro?
```
_____________________________________________________________
```

### ¿Qué fue lo más difícil o confuso?
```
_____________________________________________________________
```

### ¿Qué harías diferente la próxima vez?
```
_____________________________________________________________
```

---

## 5. Código / Archivos Entregados

| Archivo | Tipo de cambio | Descripción |
|---------|---------------|-------------|
| | Nuevo / Modificado | |
| | Nuevo / Modificado | |
| | Nuevo / Modificado | |

---

## 6. Demo / Capturas

```
Instrucciones para ejecutar la demo:
1. python server.py
2. Abrir http://localhost:8000
3. _____________________________________________
```

---

## 7. Autoevaluación (Opcional)

| Aspecto | 1 | 2 | 3 | 4 | 5 |
|---------|---|---|---|---|---|
| Facilidad de uso de Kiro | | | | | |
| Calidad del código generado | | | | | |
| Mi comprensión del resultado | | | | | |
| Productividad vs sin IA | | | | | |
| Satisfacción general | | | | | |

---

## Firma
- **Alumno:** _________________
- **Fecha de entrega:** _________________
